-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2016 at 07:55 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 7.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;



-- --------------------------------------------------------

--
-- Table structure for table `iwa2016`
--

CREATE TABLE `iwa2016` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `question` varchar(500) NOT NULL DEFAULT '0',
  `answer` varchar(500) NOT NULL DEFAULT '0',
  `status` int(20) NOT NULL DEFAULT '0',
  `joined_on`  timestamp    NOT NULL DEFAULT CURRENT_TIMESTAMP,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `status_tb` (
  `id` char(3) NOT NULL,
  `Name_status` varchar(50) NOT NULL,
  `status` int(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `Users_t` (
  `login_id` char(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(20) NOT NULL DEFAULT '0',
PRIMARY KEY (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `Time_t` (
  `Time_id` char(10) NOT NULL,
  `joined_on`  timestamp    NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (`Time_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Users_t` (`login_id`,`password`) VALUES
   					   ('20101234', '1111'   );
INSERT INTO `Users_t` (`login_id`,`password`) VALUES 					   
					   ('20101235', '1112'   ); 
INSERT INTO `Users_t` (`login_id`,`password`) VALUES
					   ('29999999', '9999'   ); 
					   	   
CREATE TABLE `Users_td` (
  `login_id` char(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(20) NOT NULL DEFAULT '0',
PRIMARY KEY (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Users_td` (`login_id`,`password`) VALUES
					   ('20101234', '1111'   ); 
INSERT INTO `Users_td` (`login_id`,`password`) VALUES
					   ('20101235', '1112'   ); 
INSERT INTO `Users_td` (`login_id`,`password`) VALUES
					   ('29999999', '9999'   ); 