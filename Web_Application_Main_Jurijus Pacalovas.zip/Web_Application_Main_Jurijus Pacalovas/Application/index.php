<!DOCTYPE html>
<html> <!-- every website or application start -->
<head>  <meta charset="utf-8">  <!-- head -->

<title>Main Assement of Web Application</title> <!-- name of web page -->
<!--jquery -->
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<p id="someElement"></p>
<p id="anotherElement"></p>


  <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.10.2.js"></script>
  <script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

<!--loyout -->
        <style>
	#header{
	background-color : #FFE446;
	border:1px solid red; 
        width:380px;
        height:100px;
        color:blue;
		float:center;
	text-align:center;
	padding:5px;
	}
	#section{
    background: url(images/messages_.jpg) TOP no-repeat; 
	border:1px solid red; 
	width:300px;
    height:800px;
 	color:#FFEA46;
	float:center;
	padding:10px;
	margin-left: 40px;
	margin-right:40px;
	}
    	</style>
</head>
	<body bgcolor="#FFF8D2"> <!-- body; color of body -->
					<br><br>
						<div id="header"><br>
	Name:  		Jurijus Pacalovas<br>
	Student: 	2015712
						</div>
			<br><br>
			<div id="section">
			    <br>
				<p align="center"><b><font color ="#FFEA46" style="font-size:14px">Main Assement of Web Application
				</font></b></p>
				<div align="right"> 
                           <div id='statustime'>
                           </div>				
                </div>
				<div align="center">
				<script>
				//fuction for time
function sendToDatabase(){
  $.get( "https://api.xmltime.com/converttime?accesskey=jp7v33r0OA&expires=2016-04-10T15%3A10%3A37%2B00%3A00&signature=RmLqOf9GuXaWAv5CEqtroRNF%2BkM%3D&version=2&fromid=ireland%2FDublin&toid=ireland%2FDublin", function( data ) {
  xml = new XMLSerializer().serializeToString(data.documentElement);
  xmlDoc = $.parseXML( xml ),
  $xml = $( xmlDoc ),
  $title = $xml.find( "time" );
    $( "#someElement" ).append( $title.text() );
  });
}
</script>
<script>
var wertd=0; //varible for login out and login 
 var stake1; var stake2; //variable for read login_id
 var stakeqw; var stakeqw1; var stakeqw2; // varible for read askquestion
 var currentIdd; var currentId = 0;  //varible send infromation from page index to ajax
 var suii=2;
 var stakew=0;
function Loginp(){// fuction login page
var  wertow; wertd=0; var dt=0; var stake; // varibles for read data from page  ajax ("stake") , "dt" login

    var var1 = document.getElementById('login').value; //id, type equal to variable
    var var2 = document.getElementById('passwordfg').value; //id, type equal to variable
    
    $.post( "ajax.php", { type: "login", login: var1, passwordfg: var2 })  //Elements equal to variables   
    .done(function( data ) {  //let take information from other page (ajax); type use for many operations
	  stakew=0;
          stake=data;//equal
          stake1=stake.substring(0, 2); //Extract characters from a string 
		  stake2=stake.substring(2, 11); //Extract characters from a string; read login_id
		     
         if(stake2=="29999999")
          {
           dt=1;//varible approprite new sense. 
			 wertd=0; //varible approprite new sense.
			 suii=1;
			 $( "#sampledialoghqqwkkol" ).hide();
			 
          }			
		  else if(stake1=="11" && stake2!="29999999")
		  //if something then do something; if stake1=="11" then varibles will approprite new senses.
		   {  suii=0;
		     dt=1;//varible approprite new sense. 
			 wertd=0; //varible approprite new sense.
			  $( "#sampledialoghqqwkkol" ).hide();
		   }
		   else if (stake1!="11" && stake2!="29999999")
		   {dt=20; wertd=20;
		   wertow="wrong password and/or login, please try again";
		    var s = document.getElementById('statusaqw'); s.innerHTML =  wertow; s.style.color = "Yellow";
		 //Elements equal to variables, show varible which Yellow color
		   $( "#sampledialoghqqwkkol" ).show();
		   }
		   
		    if(wertd==0 && dt==1 && suii==0 && stake2!="29999999") //if something then do something; if wertd==0 then start setInterval
			    {
			    setInterval(function(){if(dt==1 && wertd==0 && stake2!="29999999"){checkForAnswer();}}, 3000);
				setInterval(function(){if(dt==1 && wertd==0 && stake2!="29999999" && stakew!=8){checkstatus();}}, 1000); 
				//every three second start function checkForAnswer;
			    }
				else  if(wertd==0 && dt==1 && suii==1 && stake2=="29999999") //if something then do something; if wertd==0 then start setInterval
			    {
			    
				setInterval(function(){if(dt==1 && wertd==0 && stake2=="29999999" && stakew!=8){checkstatus();}}, 1000); 
				//every three second start function checkForAnswer;
			    }
		    if(dt==1 && suii==0)
			 {//figure bracket for tasks
		     $( "#sampledialoghqwe" ).show(); //show askquestion page
			 $( "#sampledialoghqwer" ).hide(); //hide login page
			  $( "#sampledialoghqqw" ).hide();
			  //hide <div id='statusa'> </div> <div id='statusr'> </div>   
			 } //if close; if open by figure bracket for tasks we must to close them every time 
			else if(dt==1 && suii==1)
			 {//figure bracket for tasks
		     $( "#sampledialoghqwei" ).show(); //show askquestion page
			 $( "#sampledialoghqwer" ).hide(); //hide login page
			  $( "#sampledialoghqqw" ).hide();
			  //hide <div id='statusa'> </div> <div id='statusr'> </div>   
			 } //if close; if open by figure bracket for tasks we must to close them every time 
  			
    });   
}

function login_out(){// fuction login_out
var swer;  // varible for login out
swer=stake2; 

    $.post( "ajax.php", { type: "login_out", id: swer})    //Elements equal to variables  
    .done(function( data ) { //let take information from other page (ajax); type use for many operations
	stakew=8;
	
          	currentIdd = data;
			 
			 if(currentIdd=="0") //if something then do something; if currentIdd=="0" then varible approprite new sense.
			 {
			 dt=2; //varible approprite new sense.
			 }
			
		if(dt=2)
		{
		     $( "#sampledialoghqwei" ).hide(); //hide askquestion page
             $( "#sampledialoghqwe" ).hide(); //hide askquestion page
			 $( "#sampledialoghqwer" ).show(); //hide login page
			  $( "#sampledialoghqqw" ).hide(); //hide <div id='statusa'> </div> <div id='statusr'> </div> 
		}
 			                 		 
    });
	
    
}


function checkForAnswer(){ //fuction for checkForAnswer
   
     $.post( "ajax.php", { type: "checkstatus", id:currentId})    //Elements equal to variables   
    .done(function( data ) { //let take information from other page (ajax); type use for many operations
	
    stakeqw=data;
          stakeqw1=stakeqw.substring(0, 1);   //Extract characters from a string 
		  stakeqw2=stakeqw.substring(1, 99999); //Extract characters from a string 

 if(data=="No, anwear yet" && stake2!="29999999" || data=="1No, anwear yet" && stake2!="29999999") //if something then do something;
		 {// if data=="No, anwear yet" or data=="1No, anwear yet" then do 
			//var s = document.getElementById('statusq'); s.innerHTML = stakeqw2; s.style.color = "blue";		
			//Elements equal to variables, show varible which blue color
			                  $( "#sampledialogh" ).dialog(); // dialog by jquery
			                   if(dt==2 && wertd==0) //if something then do something;
							   /*if dt==2 and wertd==0 then hide (You got an answer for your last Question!) and
								varibles approprite new senses */
								{
                                $( "#sampledialoghq" ).hide(); 
								 wertd=1;dt=1;
				                }
								
			
		 }
		 else if(data=="1")
		 //if something then do something;
		//if data=="1" then hide (You got an answer for your last Question!) and
		 {
		 $( "#sampledialoghq" ).hide();
		 }
		                     else if(stake2!="29999999")
		                     { //else Elements equal to variables, show varible which blue color
							//var s = document.getElementById('statusq'); s.innerHTML = stakeqw2; s.style.color = "blue";		
								$( "#sampledialoghq" ).dialog(); // dialog by jquery
								$( "#sampledialoghq" ).html(stakeqw2); // information output	
                                if(dt==2 && wertd==0)//if something then do something;
								// if viriable dt equal to 2 and viriable wert equal to 0 do:
								{
								$( "#sampledialoghq" ).hide // hide (You got an answer for your last Question!)
								 wertd=1;dt=1; //varibles approprite new senses
				                }  
                                
											
		                    }           
		  
    });
}
function checkstatus(){//fuction for check status
var werto; // varible for show (This Question and/or Name not exist, please try again!!!)
	 var var1 = document.getElementById('app_name').value; //Extract characters from a string
	 var var2 = document.getElementById('app_ques').value; //Extract characters from a string
     $.post( "ajax.php", { type: "checkstatusname", app_name: var1, app_ques: var2 })  //Elements equal to variables    
    .done(function( data ) {  	//let take information from other page (ajax); type use for many operations
		 if(data=="<table><tr> <td> id </td> <td> name </td> <td> question </td> <td> answer </td> <td> Status </td></tr><tr></table>")
		 //if something then do something;
		 {
		 werto="This Question and/or Name not exist, please try again!!!";
		 var s = document.getElementById('statusa'); s.innerHTML = werto; s.style.color = "Yellow";
		 //Elements equal to variables, show varible which Yellow color
		 }
		 else
		 {
	    var s = document.getElementById('statusa'); s.innerHTML = data; s.style.color = "blue";
		//Elements equal to variables, show varible which Blue color
		}
		 $( "#sampledialoghqqw" ).show();//show <div id='statusa'> </div> <div id='statusr'> </div>
    });
}

function askQuestion(){//fuction askQuestion
var suc;
suc=stake2;
    var var1i = document.getElementById('app_name').value; //Elements as id, type equal to variable
    var var2i = document.getElementById('app_ques').value; //Elements as id, type equal to variable

    $.post( "ajax.php", { type: "submitquestion", id: suc, app_name: var1i, app_ques: var2i})  //Elements equal to variables    
    .done(function( data ) { //let take information from other page (ajax); type use for many operations

 currentId = data;
          // pop up a box to the user
          $( "#sampledialog" ).dialog();	
           alert('waiting')	//message box that infomation output
           var s = document.getElementById('statusr'); s.innerHTML = data; s.style.color = "blue";
		   //Elements equal to variables, show varible which Blue color
           $( "#sampledialoghqqw" ).show();	//show <div id='statusa'> </div> <div id='statusr'> </div> 	   
    });
    setInterval(function(){if(dt==1 && wertd==0 && stake!="29999999"){checkForAnswer();}}, 3000);
	//every three second start function checkForAnswer;
}
function answerq(){//fuction askQuestion
var suc;
suc=stake2;
    var var1 = document.getElementById('app_namei').value; //Elements as id, type equal to variable
    var var2 = document.getElementById('app_quesi').value; //Elements as id, type equal to variable
    var var3 = document.getElementById('app_answer').value; //Elements as id, type equal to variable
    $.post( "ajax.php", { type: "answerq", id: suc, app_namei: var1, app_quesi: var2, app_answer: var3  })  //Elements equal to variables    
    .done(function( data ) { //let take information from other page (ajax); type use for many operations

 currentId = data;
          // pop up a box to the user
          $( "#sampledialog" ).dialog();	
           alert('waiting')	//message box that infomation output
           var s = document.getElementById('statusr'); s.innerHTML = data; s.style.color = "blue";
		   //Elements equal to variables, show varible which Blue color
           $( "#sampledialoghqqw" ).show();	//show <div id='statusa'> </div> <div id='statusr'> </div> 
		   });
	//every three second start function checkForAnswer;
}

function time()//fuction for time
{
$.post( "ajax.php", { type: "time"}) //Elements equal to variables       
    .done(function( data ) { //let take information from other page (ajax); type use for many operations
	var s = document.getElementById('statustime'); s.innerHTML = data; s.style.color = "blue";
	  //Elements equal to variables, show varible which Blue color
	});
}
time(); //time start function
setInterval(function(){time();}, 1000);
//every one second start function time;
</script>

<div id="sampledialog" title="Basic dialog"> 
  <p>Thank you, please wait!</p> 
</div>
<script>
      $( "#sampledialog" ).hide();
  </script>
  <button onclick="sendToDatabase()">Query Service</button>
  <br> 
<script>

// page login
//plus - from new line ; - close 
var html = "" +
"Login:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='login' id='login'></input><br>" +
"<br>" +
"Password:&nbsp;&nbsp;&nbsp;&nbsp; <input type='password' name='passwordfg' id='passwordfg'></input><br>" +
"<br>" +
"&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
"<button onclick='Loginp();'><font style='font-size:8px'>OK</font></button>&nbsp;" +
"<br><br><br><br>" +
"<hr></hr>";
var htmlah = "" +
"<div id='sampledialoghqwer' title='Basic dialog'>" + 
"<p>";
var htmlahj = "" +
 "</p></div>"; //output information
document.write(htmlah);
document.write(html);
document.write(htmlahj);
  $( "#sampledialoghqwer" ).show();
</script> 
<script>

//page support center
var html0i = "Support center<br><br>" +
"Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='app_namei' id='app_namei'></input><br>" +
"<br>" +
"Question:&nbsp;&nbsp;&nbsp;&nbsp; <input type='text' name='app_quesi' id='app_quesi'></input><br>" +
"<br>" +
"answer:&nbsp;&nbsp;&nbsp;&nbsp; <input type='text' name='app_anwer' id='app_answer'></input><br>" +
"<br>" +
"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
"<button onclick='answerq();'><font style='font-size:8px'>Answer</font></button>&nbsp;" +
"<button onclick='login_out();'><font style='font-size:8px'>Login out</font></button>" +
"<br><br><br><br>" +
"<div id='statusq'>" +
"</div>" +
"<hr></hr>";
var htmlai = "" +
"<div id='sampledialoghqwei' title='Basic dialog'>" + 
"<p>";
var htmlahjoi = "" +
"</p></div>"; //output information
document.write(htmlai);
document.write(html0i);
document.write(htmlahjoi);
  $( "#sampledialoghqwei" ).hide();
 </script> 

<script>

//page askquestions
var html0 = "" +
"Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='text' name='app_name' id='app_name'></input><br>" +
"<br>" +
"Question:&nbsp;&nbsp;&nbsp;&nbsp; <input type='text' name='app_ques' id='app_ques'></input><br>" +
"<br>" +
"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +
"<button onclick='askQuestion();'><font style='font-size:8px'>Submit</font></button>&nbsp;" +
"<button onclick='login_out();'><font style='font-size:8px'>Login out</font></button>" +
"<br><br><br><br>" +
"<div id='statusq'>" +
"</div>" +
"<hr></hr>";
var htmla = "" +
"<div id='sampledialoghqwe' title='Basic dialog'>" + 
"<p>";
var htmlahjo = "" +
"</p></div>"; //output information
document.write(htmla);
document.write(html0);
document.write(htmlahjo);
  $( "#sampledialoghqwe" ).hide();
 </script>
 

<div id='sampledialogh' title='Basic dialog'> 
  <p> <!-- new poragraph -->
No, answer yet
</p>
</div>
 

</script>
<script>
      $( "#sampledialogh" ).hide();
  </script>
  
  <div id='sampledialoghq' title='Basic dialog'> 
  <p>
You got an answer for your last Question!
</p>
</div>

</script>
<script>
      $( "#sampledialoghq" ).hide();
  </script>

<hr></hr> 
<div id='sampledialoghqqwkkol' title='Basic dialog'> 
  <p>
<div id='statusaqw'>
</div>
</div>
<!-- open javascript; close java script -->
<script> 
      $( "#sampledialoghqqwkkol ).hide();
  </script>

 <div id='sampledialoghqqw' title='Basic dialog'> 
  <p>
<div id='statusa'>
</div>
<div id='statusr'>
</div>
</p>
</div>
<!-- open javascript; close java script -->
<script> 
      $( "#sampledialoghqqw" ).hide();
  </script>

<hr></hr> <!-- line -->
<br><br><br>

</div></div></div></div></div>

</body> <!-- body close; nearly every tag close -->
</html> <!-- html close -->